local fall_delay = 0.1

function on_place(world, position)
    sounds:play_for_block("see_see", "place", position, 1.0, 1.0)
    worldticker:schedule(position, fall_delay)
end

function on_break(world, position)
    sounds:play_for_block("see_see", "break", position, 0.7, 0.8)
end

function on_tick(world, position, delta_time)
    check_fall(world, position)
end

function check_fall(world, position)
    local below = vec3int.new(position.x, position.y - 1, position.z)
    print("Checking fall for see_see at " .. position.x .. ", " .. position.y .. ", " .. position.z .. " against block below at " .. below.x .. ", " .. below.y .. ", " .. below.z)
    print("Block below: " .. world:block_at(below))

    if position.y > 0 and world:block_at(below) == "air" then
        world:remove_block(position)
        world:set_block(below, "see_see")
        sounds:play_for_block("see_see", "break", position, 0.7, 0.8)
        worldticker:schedule(below, fall_delay)
    end
end
